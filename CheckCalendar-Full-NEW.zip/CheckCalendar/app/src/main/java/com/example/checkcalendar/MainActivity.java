package com.example.checkcalendar;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    TrackerView view; SharedPreferences sp;
    final int BG=Color.BLACK, PANEL=Color.rgb(31,31,31), GRID=Color.rgb(52,52,52), TEXT=Color.rgb(235,235,235), MUTED=Color.rgb(145,145,145), GREEN=Color.rgb(62,190,88), BLUE=Color.rgb(42,126,235);
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG); sp=getSharedPreferences("data",0); view=new TrackerView(this);setContentView(view);}
    void editTab(final int index, boolean add){
        final EditText input=new EditText(this); input.setSingleLine(); input.setTextColor(TEXT); input.setHintTextColor(MUTED); input.setHint("Tab name"); if(!add) input.setText(view.tabs.get(index));
        int pad=40; FrameLayout box=new FrameLayout(this); box.setPadding(pad,0,pad,0); box.addView(input);
        new AlertDialog.Builder(this).setTitle(add?"Add tab":"Rename tab").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String n=input.getText().toString().trim();if(n.isEmpty())return;if(add){view.tabs.add(n);view.active=view.tabs.size()-1;}else view.tabs.set(index,n);view.saveTabs();view.invalidate();}).show();
    }
    void manageTabs(){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(24,8,24,8);
        for(int i=0;i<view.tabs.size();i++){final int k=i;LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL); TextView t=new TextView(this);t.setText(view.tabs.get(i));t.setTextColor(TEXT);t.setTextSize(17);t.setPadding(10,18,10,18);row.addView(t,new LinearLayout.LayoutParams(0,-2,1));Button e=new Button(this);e.setText("Edit");e.setOnClickListener(v->{editTab(k,false);});row.addView(e);Button x=new Button(this);x.setText("Delete");x.setOnClickListener(v->{if(view.tabs.size()==1){Toast.makeText(this,"Keep at least one tab",Toast.LENGTH_SHORT).show();return;}view.tabs.remove(k);view.active=Math.max(0,Math.min(view.active,view.tabs.size()-1));view.saveTabs();view.invalidate();});row.addView(x);l.addView(row);}
        new AlertDialog.Builder(this).setTitle("Manage tabs").setView(l).setPositiveButton("Add tab",(d,w)->editTab(-1,true)).setNegativeButton("Done",null).show();
    }
    void showInfo(String title,String msg){new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK",null).show();}

    class TrackerView extends View {
        Paint p=new Paint(3); ArrayList<String> tabs=new ArrayList<>(); int active=0; Calendar month=Calendar.getInstance(); int page=0;
        RectF r=new RectF();
        TrackerView(Context c){super(c);p.setTypeface(Typeface.create("sans",Typeface.NORMAL)); loadTabs(); month.set(Calendar.DAY_OF_MONTH,1); setBackgroundColor(BG);}
        void loadTabs(){String s=sp.getString("tabs","");if(s.isEmpty()){tabs.add("Aug-Sept");tabs.add("Sept-Oct");}else tabs.addAll(Arrays.asList(s.split("\\|",-1)));active=Math.min(sp.getInt("active",0),tabs.size()-1);}
        void saveTabs(){StringBuilder b=new StringBuilder();for(String t:tabs){if(b.length()>0)b.append('|');b.append(t.replace("|","/"));}sp.edit().putString("tabs",b.toString()).putInt("active",active).apply();}
        String key(int y,int m,int d){return "m"+active+"_"+y+"_"+m+"_"+d;}
        int state(int y,int m,int d){return sp.getInt(key(y,m,d),0);}
        void setState(int y,int m,int d,int s){sp.edit().putInt(key(y,m,d),s).apply();}
        int totalAll(){int total=0; Calendar c=Calendar.getInstance(); for(int y=c.get(Calendar.YEAR)-10;y<=c.get(Calendar.YEAR)+10;y++)for(int m=0;m<12;m++)for(int d=1;d<=31;d++){Calendar x=new GregorianCalendar(y,m,d);if(x.get(Calendar.MONTH)!=m)continue;int s=state(y,m,d);total+=s;}return total;}
        int totalMonth(){int total=0;int y=month.get(Calendar.YEAR),m=month.get(Calendar.MONTH);int max=month.getActualMaximum(Calendar.DAY_OF_MONTH);for(int d=1;d<=max;d++)total+=state(y,m,d);return total;}
        void txt(Canvas c,String s,float x,float y,float size,int color,Paint.Align align){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTextAlign(align);p.setTypeface(Typeface.create("sans",Typeface.NORMAL));c.drawText(s,x,y,p);}
        void bold(Canvas c,String s,float x,float y,float size,int color,Paint.Align align){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTextAlign(align);p.setTypeface(Typeface.create("sans",Typeface.BOLD));c.drawText(s,x,y,p);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();
            // top tabs
            p.setColor(Color.rgb(35,35,35));c.drawRect(0,0,w,78,p);float tabW=Math.min(205,w/(float)Math.max(2,tabs.size()+1));for(int i=0;i<tabs.size();i++){float x=i*tabW;if(i==active){p.setColor(Color.BLACK);c.drawRoundRect(new RectF(x,0,x+tabW,78),25,25,p);}txt(c,tabs.get(i),x+28,48,25,TEXT,Paint.Align.LEFT);int count=tabTotal(i);p.setColor(Color.rgb(74,74,74));c.drawCircle(x+tabW-48,39,18,p);bold(c,""+count,x+tabW-48,45,14,TEXT,Paint.Align.CENTER);}txt(c,"+",Math.min(w-205,tabs.size()*tabW)+28,48,36,Color.LTGRAY,Paint.Align.LEFT);txt(c,"☷",w-30,49,30,Color.LTGRAY,Paint.Align.CENTER);
            float top=98;txt(c,new SimpleDateFormat("MMMM yyyy",Locale.US).format(month.getTime())+"⌄",20,top+35,28,TEXT,Paint.Align.LEFT);txt(c,"All Time",w-145,top+30,16,TEXT,Paint.Align.RIGHT);bold(c,""+totalAll(),w-82,top+36,36,TEXT,Paint.Align.CENTER);txt(c,"⋯",w-25,top+36,34,TEXT,Paint.Align.CENTER);
            String[] days={"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};float gridTop=top+92;float cw=w/7f;for(int i=0;i<7;i++)txt(c,days[i],cw*i+cw/2,gridTop-26,17,TEXT,Paint.Align.CENTER);
            int first=month.get(Calendar.DAY_OF_WEEK)-1,max=month.getActualMaximum(Calendar.DAY_OF_MONTH);int rows=(int)Math.ceil((first+max)/7.0);float cellH=Math.min(110,(h-gridTop-90)/Math.max(5,rows));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(GRID);for(int rr=0;rr<=rows;rr++)c.drawLine(0,gridTop+rr*cellH,w,gridTop+rr*cellH,p);for(int cc=0;cc<=7;cc++)c.drawLine(cc*cw,gridTop,cc*cw,gridTop+rows*cellH,p);
            Calendar today=Calendar.getInstance();for(int d=1;d<=max;d++){int pos=first+d-1,rr=pos/7,cc=pos%7;float x=cc*cw,y=gridTop+rr*cellH;boolean isToday=today.get(Calendar.YEAR)==month.get(Calendar.YEAR)&&today.get(Calendar.MONTH)==month.get(Calendar.MONTH)&&today.get(Calendar.DAY_OF_MONTH)==d;if(isToday){p.setStyle(Paint.Style.FILL);p.setColor(BLUE);c.drawCircle(x+cw/2,y+28,22,p);}txt(c,""+d,x+cw/2,y+34,17,isToday?Color.WHITE:TEXT,Paint.Align.CENTER);int s=state(month.get(Calendar.YEAR),month.get(Calendar.MONTH),d);if(s>0){drawCheck(c,x+cw/2-7,y+cellH/2+12);if(s==2)txt(c,"x2",x+cw/2+24,y+cellH/2+17,18,TEXT,Paint.Align.LEFT);}}
            // floating nav and bottom nav
            float fy=h-150; circle(c,w/2-90,fy,48);txt(c,"☷",w/2-90,fy+11,30,Color.WHITE,Paint.Align.CENTER);circle(c,w/2+15,fy,48);txt(c,"‹",w/2+15,fy+13,42,Color.WHITE,Paint.Align.CENTER);circle(c,w/2+125,fy,48);txt(c,"›",w/2+125,fy+13,42,Color.WHITE,Paint.Align.CENTER);
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(26,26,26));c.drawRect(0,h-82,w,h,p);String[] nav={"⌂","⌁","◷","?","⚙"};String[] lab={"Home","Report","History","Usage","Settings"};for(int i=0;i<5;i++){float x=(i+.5f)*w/5;int col=i==page?Color.WHITE:Color.GRAY;txt(c,nav[i],x,h-48,28,col,Paint.Align.CENTER);txt(c,lab[i],x,h-20,14,col,Paint.Align.CENTER);}
        }
        int tabTotal(int idx){int old=active;active=idx;int total=totalAll();active=old;return total;}
        void circle(Canvas c,float x,float y,float rad){p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(27,27,27));c.drawCircle(x,y,rad,p);}
        void drawCheck(Canvas c,float x,float y){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(8);p.setStrokeCap(Paint.Cap.SQUARE);p.setColor(GREEN);Path q=new Path();q.moveTo(x-24,y-2);q.lineTo(x-8,y+14);q.lineTo(x+22,y-18);c.drawPath(q,p);p.setStrokeCap(Paint.Cap.BUTT);}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();
            if(y<80){float tw=Math.min(205,w/(float)Math.max(2,tabs.size()+1));int idx=(int)(x/tw);if(idx<tabs.size()){active=idx;saveTabs();invalidate();}else if(x>tabs.size()*tw&&x<w-70){editTab(-1,true);}}
            else if(y>h-82){page=(int)(x/(w/5)); if(page==1)showReport(); else if(page==2)showHistory(); else if(page==3)showUsage(); else if(page==4)manageTabs(); invalidate();}
            else if(y>h-205&&y<h-95){if(x>w/2-130&&x<w/2-45){month.add(Calendar.MONTH,-1);invalidate();}else if(x>w/2+70){month.add(Calendar.MONTH,1);invalidate();}else if(x>w/2-130&&x<w/2-45){} }
            else {float top=190; if(y>top){int first=month.get(Calendar.DAY_OF_WEEK)-1;float cw=w/7f;float cellH=Math.min(110,(h-top-90)/6f);int cc=(int)(x/cw),rr=(int)((y-top)/cellH),d=rr*7+cc-first+1;if(d>=1&&d<=month.getActualMaximum(Calendar.DAY_OF_MONTH)){int s=state(month.get(Calendar.YEAR),month.get(Calendar.MONTH),d);setState(month.get(Calendar.YEAR),month.get(Calendar.MONTH),d,(s+1)%3);invalidate();}}}
            return true; }
        void showReport(){StringBuilder b=new StringBuilder();for(int i=0;i<tabs.size();i++){int old=active;active=i;b.append(tabs.get(i)).append(": ").append(totalAll()).append(" checks\n");active=old;}showInfo("Report",b.toString());}
        void showUsage(){showInfo("Usage","All-time checks: "+totalAll()+"\nThis month: "+totalMonth()+"\nTap a date to cycle: blank → ✓ → ✓ x2 → blank.");}
        void showHistory(){StringBuilder b=new StringBuilder();Calendar now=Calendar.getInstance();SimpleDateFormat f=new SimpleDateFormat("dd MMM yyyy",Locale.US);int old=active;int found=0;for(int y=now.get(Calendar.YEAR);y>=now.get(Calendar.YEAR)-2&&found<30;y--)for(int m=11;m>=0&&found<30;m--)for(int d=31;d>=1&&found<30;d--){Calendar z=new GregorianCalendar(y,m,d);if(z.get(Calendar.MONTH)!=m)continue;int s=state(y,m,d);if(s>0){b.append(f.format(z.getTime())).append("  ").append(s==2?"✓ x2":"✓").append("\n");found++;}}active=old;if(found==0)b.append("No checks yet.");showInfo("History",b.toString());}
    }
}
