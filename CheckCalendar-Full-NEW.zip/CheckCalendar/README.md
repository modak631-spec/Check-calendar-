# Check Calendar 2.0

A standalone Android app modeled on the supplied Check Calendar screenshots.

Features:
- Dark calendar UI
- Multiple customizable tabs (default: Aug-Sept, Sept-Oct)
- Add and rename tabs; delete tabs (at least one remains)
- Per-tab persistent date states
- Tap date: blank -> single green check -> green check x2 -> blank
- Automatic All Time totals
- Current date blue circle
- Previous/next month controls
- Report, History and Usage screens
- Offline persistence with SharedPreferences
- No external libraries

Build with Android Studio using Android Gradle Plugin 8.6.1 and SDK 35.

- Launcher icon: double green check logo.
